package com.multi.bitlyclient.util;

public class Settings {
	public static final String CLIENT_ID = "860c5ec117be2c9bda7d0eb7face3c138624af07";
	public static final String CLIENT_SECRET = "e1fb371d0c03522dd1e8074bc026d6a7b0a1b50e";
	public static final String AUTHORIZE_URL="https://bitly.com/oauth/authorize";
	public static final String ACCES_TOKEN_URL = "https://api-ssl.bitly.com/oauth/access_token";
	public static final String REDIRECT_URI = "http://jcornor.com:8000/callback";
	public static final String SHORTEN_API_URL = "https://api-ssl.bitly.com/v4/shorten";
}
