package com.multi.contactsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactswebApplicationTests {

	@Test
	void contextLoads() {
	}

}
